# Video text - wrapping, selectable, stylable from CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/thebabydino/pen/MYeVLZw](https://codepen.io/thebabydino/pen/MYeVLZw).

The best way to make text come alive.

Turn boring headlines into dynamic video ones, where the text can wrap naturally, is selectable, can be copied, allows for any backdrop (heck, you may even add another `<video>` or an interactive `<canvas>` behind) and is easily stylable from the CSS. All with this cross-browser approach which has been tested to work well across a wide range of user circumstances.

Plain HTML and CSS. Heavily commented, making it easy for you to modify. For example, you can choose whether you want to keep the inset text shadow or ditch it. You can choose what kind of backdrop you want for the text.

No AI slop. It's the result of years of refining techniques, carefully considering various and testing scenarios to go around browser issues (as well as filing bugs in hope things get fixed and we don't need the workarounds). I almost lost my mind and threw my laptop out the window and myself with it so you don't have to.

---

Wait, why the JavaScript? To add/ respond to a manual Play/ Pause button.

Wait, wasn't the video autoplaying? Well, the user might block autoplaying videos from browser settings. Or may have reduced motion/ reduced data preferences that don't go well with an autoplaying video. For these cases, we add a play/ pause button so the video can still play if the user decides to do so.

Wait, couldn't we just somehow style the video's own play/ pause button and use that to make it work without JS? May Satan help you with that, I can't.

Then there's also the aspect of not wanting the video to keep on playing when it has moved completely outside the viewport. In this case, we pause the video while it's out of sight using the IntersectionObserver API. We can do a lot of things with scroll-driven animations, but we cannot play/ pause a video.

---

A short recap of earlier video text solutions found online for comparison

Over time, I've seen this done in a number of ways, all of them less than ideal, not to mention none of them took into account performance and accessibility.

The simplest one today is making the text and its background pure `white` and `black` (or the other way around) and blending it with the video stacked behind using a `darken`/ `multiply` blend mode (or `lighten`/ screen` if we have `black` text on `white` background).

Unfortunately, this often doesn't work so well if we want to have a background that's not `black` or `white`. And it's best to avoid pure `black` and `white` on the web. We can get around this limitation, but the workaround involves duplicating the text.

Another issue with this method is that, unless we have specific styles for this (which I haven't seen any of the examples floating around to add), produces inconsistent results between light and dark themes in high contrast mode.

I've also seen this done using an SVG text `mask`. Unfortunately, SVG `text` cannot wrap naturally, line breaks must be inserted manually. And no, `<foreignObject>` is not a solution - it does not work inside `<mask>`. And since this is just a `<video>` element with a `mask`, it's not selectable as text. We could fix that with an invisible text copy on top, but duplicating the text isn't idea, plus this crates the problem of perfectly aligning the two text versions. Not to mention that this approach isn't even cross-browser - it doesn't work in Safari.

A similar approach I've seen is using an SVG `clip-path` (which basically turns the text letters into a `<path>`) . This has the same disadvantages tied to the text not wrapping naturally and not being selectable.

Another similar approach is creating the video text on a canvas. In addition to the text not wrapping naturally, not being selectable, potential issues with proper alignment depending on the font used, it also requires JS strictly for the visual part.

Of course, these days, I'm also seeing AI solutions that don't even work at all, such as setting the video as a `background-image` and clipping it to `text`.

### Like this?

If the work I've been putting out since early 2012 has helped you in any way or you just like it, then please remember that praise doesn't keep me afloat financially... but you can! So please consider supporting my work in one of the following ways if you want me to be able to continue coding:

* being a cool cat 😼🎩 and supporting it monthly on Ko-fi or via a one time donation

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* making a weekly anonymous donation via Liberapay - I'll never know who you are if that's your wish

[![Liberapay](https://assets.codepen.io/2017/btn_liberapay.svg)](https://liberapay.com/anatudor/)

* getting me a chocolate voucher

[![Zotter chocolate](https://assets.codepen.io/2017/zotter.jpg)](https://www.zotter.at/en/online-shop/gifts/gift-vouchers/choco-voucher)

* if you're from outside Europe, becoming a patron on Patreon (don't use it for one time donations or if you're from Europe, we're both getting ripped off)

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* or at least sharing this to show the world what can be done with CSS these days

Thank you!

---

Dedicated to the memory of someone dear who passed away in January 2019. Missing you every day.