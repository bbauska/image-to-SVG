const FN = ['play', 'pause']

function getUpstream(_el, cls) {
	if(_el === document.body) return null;
	if(_el.classList.contains(cls)) return _el;
	return getUpstream(_el.parentNode, cls)
}

function update(_btn, bit = 0) {
	_btn.textContent = FN[bit]
}

function manual(_vid, bit = 0) {
	let _cont = getUpstream(_vid, 'video-text-container'), 
				_btn = null;
	
	_vid.dataset.auto = bit;
	_vid[FN[1 - bit]]();

	if(_cont) {
		let _btn = document.createElement('button');

		_btn.classList.add('play-ctrl');
		update(_btn, bit);
		_cont.appendChild(_btn);
		
		return _btn
	}
}

addEventListener('DOMContentLoaded', e => {
	const _VIDS = [...document.querySelectorAll('video')];
	
	_VIDS.forEach((_vid, i) => {
		let _btn = null, bit = 0;
		
		if(+getComputedStyle(_vid).getPropertyValue('--auto')) {
			let promise = _vid.play();
			
			/* detect if browsers block autoplaying videos and  
		 	 * add play/ pause controls in that event */
			if(promise !== undefined)
				promise.then(_ => { _btn = manual(_vid, 1) })
					     .catch(err => { _btn = manual(_vid, 0) })
		}
		else _btn = manual(_vid, 0);
		
		/*  pause autoplaying videos if outside viewport */
		observer = new IntersectionObserver((entries) => {
			entries.forEach((entry) => {
				if(!Math.ceil(entry.intersectionRatio)) {
					_vid.pause();
					update(_btn)
				}
			});
		});
		
		observer.observe(_vid);/* okay this doesn't work right */
	});
	
	addEventListener('click', e => {
		let _t = e.target;
		
		if(_t.tagName.toLowerCase() === 'button') {
			let bit = +FN.indexOf(_t.textContent), 
					_cont = getUpstream(_t, 'video-text-container'), 
					_vid = null;
						
			if(_cont) _vid = _cont.querySelector('video');
			
			if(_vid) {
				update(_t, 1 - bit);
				_vid[FN[bit]]()
			}
		}
	})
})